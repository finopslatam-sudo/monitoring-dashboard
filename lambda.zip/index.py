def handler(event, context): return {"status": "ok"}
